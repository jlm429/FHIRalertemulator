angular.module('firebase.config', [])
  .constant('FBURL', 'https://oscartest.firebaseio.com');
